import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.io.IOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.util.ArrayList;
import java.util.Collections;
import java.util.LinkedList;
import java.util.List;
import java.util.Queue;

import javax.print.attribute.standard.MediaSize.Other;
import javax.swing.DefaultListModel;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;

public class MainWindow extends JFrame {

	private DefaultListModel<String> historyListModel;
	private JList<String> historyList;

	public JLabel snapshot1Label;
	private JButton snapshot1Button;

	private JLabel snapshot2Label;
	private JButton snapshot2Button;

	private JLabel snapshot3Label;
	private JButton snapshot3Button;
	private static Hanger[] hangers = new Hanger[3];
	
	public static void main(String[] args) throws IOException, InterruptedException {
		MainWindow mainWindow = new MainWindow();
		mainWindow.setVisible(true);
		
		//init
		List<Integer> otherPorts = new ArrayList<Integer>();
		List<String> otherHangers = new ArrayList<String>();

		for(int i = 1; i<4 ;i++) {
			
			String name = "H"+i;
			
			otherHangers.add(name);
			otherPorts.add(8080+i);
			Hanger h = new Hanger(name,8080+i,mainWindow);
			hangers[i-1]=h;
		}
		
		
		for(Hanger h : hangers) {
			h.setOtherHanger(otherPorts,otherHangers);
		}
		for(Hanger h : hangers) {
			h.run();
		}
		
	}

	public MainWindow() {
		setSize(400, 300);
		setTitle("TK1-EX6");
		setDefaultCloseOperation(EXIT_ON_CLOSE);

		// history list
		historyListModel = new DefaultListModel<String>();
		historyList = new JList<String>(historyListModel);
		historyList.setAutoscrolls(true);
		
		JScrollPane historyScroll = new JScrollPane(historyList);
		add(historyScroll, BorderLayout.CENTER);

		// slide panel
		JPanel sidePanel = new JPanel();
		sidePanel.setLayout(new GridLayout(3, 1));

		// snapshot 1
		snapshot1Label = new JLabel("Hangar 1 (#0)");
		snapshot1Button = new JButton("Snapshot");
		snapshot1Button.addActionListener(x -> {
			try {
				snapshot(1);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

		JPanel snapshot1 = new JPanel();
		snapshot1.setLayout(new GridLayout(2, 1));
		snapshot1.add(snapshot1Label);
		snapshot1.add(snapshot1Button);
		sidePanel.add(snapshot1);

		// snapshot 2
		snapshot2Label = new JLabel("Hangar 2 (#0)");
		snapshot2Button = new JButton("Snapshot");
		snapshot2Button.addActionListener(x -> {
			try {
				snapshot(2);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

		JPanel snapshot2 = new JPanel();
		snapshot2.setLayout(new GridLayout(2, 1));
		snapshot2.add(snapshot2Label);
		snapshot2.add(snapshot2Button);
		sidePanel.add(snapshot2);

		// snapshot 3
		snapshot3Label = new JLabel("Hangar 3 (#0)");
		snapshot3Button = new JButton("Snapshot");
		snapshot3Button.addActionListener(x -> {
			try {
				snapshot(3);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		});

		JPanel snapshot3 = new JPanel();
		snapshot3.setLayout(new GridLayout(2, 1));
		snapshot3.add(snapshot3Label);
		snapshot3.add(snapshot3Button);
		sidePanel.add(snapshot3);

		add(sidePanel, BorderLayout.EAST);
	}

	private void snapshot(int snapshot) throws IOException {
		// TODO
		historyListModel.addElement("Snapshot: H"+snapshot+" initiator");
		hangers[snapshot-1].snapshot();
	}
	
	// set Table
	public void addHistory(String s) {
		historyListModel.addElement(s);
	}
	
	public void setCount(String string,int count) {
		int i = Integer.valueOf(string.substring(1)).intValue();
		switch (i) {
		
		case 1:
			
			snapshot1Label.setText("Hangar 1 (#"+count+")");
			break;
			
		case 2:
			snapshot2Label.setText("Hangar 2 (#"+count+")");
			break;
		case 3:
			snapshot3Label.setText("Hangar 3 (#"+count+")");
			break;
		}
		
	}

}
