import java.io.IOException;
import java.net.DatagramPacket;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.LinkedList;
import java.util.Queue;

import javax.print.attribute.standard.MediaSize.Other;

public class Channel extends Thread  {
	
	public Hanger hanger;
	boolean snapshot =false;
	int count = -1;
	int type;
	public Channel(Hanger h, int i) {
		hanger = h;
		type = i;
		
	}
	
	public void send() throws InterruptedException, IOException {
        
	    while (true) {
	    	if(!snapshot) {
	    		if(hanger.currentFlights>0) {
		    		int i = 1 + (int)(Math.random() * (5));
		    		if(i>hanger.currentFlights) {
		    			continue;
		    		}
		    		int randomHanger = 0 + (int)(Math.random() * (1-0+1));
			    	String s ="Transfer: " + hanger.name+"-> "+ hanger.otherHangers.get(randomHanger)+ " ("+i+")";
			    	byte[] msg = s.getBytes();
			    	
			    	
			    	InetAddress address = InetAddress.getByName("localhost");
			    	int port = hanger.otherPorts.get(randomHanger);
			    	DatagramPacket packet = new DatagramPacket(msg, msg.length,address,port);
			    	hanger.socket.send(packet);
			    	this.hanger.currentFlights-=i;	
		    	}
	    		
	    	}
	    	
	    	int delay = 1000 + (int)(Math.random() * (2000+1));
	    	Thread.sleep(delay);
	    	
	    }      
	 }
	
	public void receive() throws IOException, InterruptedException {
		int snapCount;
		while (true) {
			
			byte[] buf = new byte[256];
			DatagramPacket packet = new DatagramPacket(buf, buf.length);
			hanger.socket.receive(packet);
	        String received = new String(packet.getData(), 0, packet.getLength());
	        hanger.mainWindow.addHistory(received);
	        if(received.startsWith("Transfer")) {
	        	String number = received.substring(received.length()-2,received.length()-1);
	        	int i = Integer.valueOf(number);
	        	hanger.currentFlights+=i;
	        	hanger.mainWindow.setCount(hanger.name, this.hanger.currentFlights);
	        }
	        else{
	        	if(count==-1) {
	        		count = 1;
	        		this.snapshot();
	        	}
	        	else if(count == 2) {
	        		count --;
	        	}
	        	else if(count == 1){
	        		count --;
	        	}

	        }
	        
	        int delay = 1000 + (int)(Math.random() * (2000+1));
	    	Thread.sleep(delay);
			
		}
		
	}

	@Override
	public void run() {
		// TODO Auto-generated method stub
		switch (type) {
		case 0:
			try {
				this.receive();
				
			} catch (InterruptedException | IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			break;

		case 1:
			try {
				this.send();
			} catch (IOException | InterruptedException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
	}
	
	public void snapshot() throws IOException {
		this.snapshot = true;
		for(int i =0 ;i<hanger.otherHangers.size();i++) {
    		InetAddress address = InetAddress.getByName("localhost");
    		int port = hanger.otherPorts.get(i);
    		String hangerName = hanger.otherHangers.get(i);
    		String s ="Mark: " + hanger.name+"-> "+ hangerName;
	    	byte[] msg = s.getBytes();
	    	DatagramPacket packet = new DatagramPacket(msg, msg.length,address,port);
	    	hanger.socket.send(packet);
		}
		this.snapshot = false;
		
	}
	
	public void setCountForAnswer(int count) {
		this.count=count;
	}
}
