import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.Socket;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.util.List;
import java.util.Queue;

import javax.sound.midi.Receiver;
import javax.swing.JLabel;


public class Hanger implements Runnable {
	public String name;  // eg."H1"
	public Channel incomingChannel;
	public Channel outGoingChannel;
	public int currentFlights;    // the amount of flights this hanger has
	
	
	public DatagramSocket socket;
	public MainWindow mainWindow;
	public List<Integer> otherPorts = new ArrayList<>();
	public List<String>otherHangers = new ArrayList<>();
	public Hanger(String name,int port,MainWindow mainWindow) throws IOException, InterruptedException {
		this.name = name;
		this.currentFlights = 10;
		this.mainWindow=mainWindow;		
		socket = new DatagramSocket(port);  
		
		mainWindow.setCount(this.name, this.currentFlights);
        // start to send and receive
		
	}
	
	
	public void setOtherHanger(List<Integer>otherPorts,List<String> otherHangers) throws InterruptedException, IOException{
		
		int i = Integer.valueOf(name.substring(1));
		this.otherHangers.addAll(otherHangers);
		this.otherPorts.addAll(otherPorts);
		this.otherPorts.remove(i-1);
		this.otherHangers.remove(i-1);	
		
	}


	@Override
	public void run() {
		
		outGoingChannel = new Channel(this,1);
		incomingChannel = new Channel(this,0);
		
		
		outGoingChannel.start();
		incomingChannel.start();
		
	}
	
	public void snapshot() throws IOException {
		outGoingChannel.snapshot();
		
		incomingChannel.setCountForAnswer(otherHangers.size());
		
		
	}
	
	
}
